#!/bin/bash

echo Coloque o arquivo composer.phar na sua area de trabalho
read -n1 -r -p "Aperte qualquer tecla para seguir..." key
echo Digite o seu usuario, ou seja, numero de matricula:
read matricula
alias composer="/c/Users/$matricula/Desktop/composer.phar"
export PATH=/c/xampp/php:/mingw64/bin:/usr/bin
cd /c/Users/$matricula/Desktop/
git clone https://github.com/phasenraum2010/phppetclinic.git
cd /c/Users/$matricula/Desktop/phppetclinic/phppetclinic/
git config --global http.proxy http://192.168.7.253:8080
git config --global https.proxy http://192.168.7.253:8080
export HTTPS_PROXY_REQUEST_FULLURI=false
export HTTP_PROXY="http://192.168.7.253:8080"
read -n1 -r -p "
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
Agora o script instalara as dependencias do projeto, quando o doctrine 
requisitar que voce digite alguns dados em relacao a IPs e portas, 
simplesmente os ignore e somente altere o database_name.
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
Digite uma tecla para continuar..." key
composer install
php app/console doctrine:database:create
php app/console doctrine:schema:update --force
read -n1 -r -p "
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
Instalacao finalizada, para executar o projeto voce deve digitar
'php app/console server:run'. Para entender como se cria o BD com
doctrine, visite http://symfony.com/doc/current/book/doctrine.html
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||" key