1 - Coloque o instalador.sh e o composer.phar na sua area de trabalho.
2 - Abra o git bash
3 - Digite "source /c/Users/(Seu n�mero de matr�cula, sem os par�nteses)/Desktop/instalador.sh"
4 - Siga os passos do script e pronto, agora � s� configurar o banco com o link disponibilizado.

Extra.1: Para executar o projeto digite: 'php app/console server:run' dentro da pasta raiz do projeto, que � onde o composer se localiza.

Extra.2: Caso voc� feche o bash, voc� pode digitar "source /c/Users/(Seu n�mero de matr�cula, sem os par�nteses)/Desktop/configurar.sh" disponibilizado juntamente com o instalador, para que o bash entenda os par�metros do composer/php/git.

Guilherme Matuella.